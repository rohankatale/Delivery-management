package com.loginext.deliverymanagement.Controller;

import com.loginext.deliverymanagement.Dto.DeliveryAssignmentRequest;
import com.loginext.deliverymanagement.Service.DeliveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/delivery")
public class DeliveryController {

    @Autowired
    private DeliveryService deliveryService;

    @PostMapping("/assign")
    public ResponseEntity<List<String>> assignOrders(@RequestBody DeliveryAssignmentRequest request) {
        if (request.getOrders() == null || request.getOrders().isEmpty() || request.getNumDrivers() <= 0) {
            return ResponseEntity.badRequest().body(List.of("Invalid input provided."));
        }

        List<String> results = deliveryService.processAssignments(request.getNumDrivers(), request.getOrders());
        return ResponseEntity.ok(results);
    }
}