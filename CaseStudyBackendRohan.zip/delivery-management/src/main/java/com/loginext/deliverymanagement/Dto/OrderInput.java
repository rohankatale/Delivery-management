package com.loginext.deliverymanagement.Dto;
import lombok.Data;

@Data
public class OrderInput {
    private int orderTime;
    private int travelTime;
}