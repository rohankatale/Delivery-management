package com.loginext.deliverymanagement.Repository;

import com.loginext.deliverymanagement.Model.AssignmentResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AssignmentResultRepository extends JpaRepository<AssignmentResult, Long> {

}
