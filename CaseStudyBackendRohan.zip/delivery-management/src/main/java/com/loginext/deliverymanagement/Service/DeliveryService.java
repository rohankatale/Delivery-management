package com.loginext.deliverymanagement.Service;

import com.loginext.deliverymanagement.Dto.OrderInput;
import com.loginext.deliverymanagement.Model.AssignmentResult;
import com.loginext.deliverymanagement.Repository.AssignmentResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeSet;

@Service
public class DeliveryService {

    @Autowired
    private AssignmentResultRepository assignmentResultRepository;

    private static class DeliveryBoy {
        int idx;
        int ft;
        DeliveryBoy(int idx, int ft) {
            this.idx = idx;
            this.ft = ft;
        }
    }

    @Transactional
    public List<String> processAssignments(int numDrivers, List<OrderInput> orders) {

        int N = orders.size();
        int M = numDrivers;

        List<String> assignmentOutputs = new ArrayList<>();

        PriorityQueue<DeliveryBoy> queue = new PriorityQueue<>(
                (a, b) ->  Integer.compare(a.ft, b.ft)
        );

        for (int i = 1; i <= M; i++) {
            queue.add(new DeliveryBoy(i, 0));
        }

        TreeSet<Integer> available = new TreeSet<>();

        int customerIdx = 1;

        for (OrderInput order : orders) {

            int O = order.getOrderTime();
            int T = order.getTravelTime();

            while (!queue.isEmpty() && queue.peek().ft < O) {
                DeliveryBoy db = queue.poll();
                available.add(db.idx);
            }

            String currentCustomerId = "C" + customerIdx;

            if (!available.isEmpty()) {
                int assignedIdx = available.pollFirst();
                String assignedDriverId = "D" + assignedIdx;

                String output = currentCustomerId + " - " + assignedDriverId;
                assignmentOutputs.add(output);

                int newFreeTime = O + T;
                queue.add(new DeliveryBoy(assignedIdx, newFreeTime));

                AssignmentResult result = new AssignmentResult(currentCustomerId, O, T, assignedDriverId, "ASSIGNED");
                assignmentResultRepository.save(result);

            } else {
                String output = currentCustomerId + " - No Food :-(";
                assignmentOutputs.add(output);

                AssignmentResult result = new AssignmentResult(currentCustomerId, O, T, null, "REJECTED");
                assignmentResultRepository.save(result);
            }
            customerIdx++;
        }

        return assignmentOutputs;
    }
}