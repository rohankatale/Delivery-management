package com.loginext.deliverymanagement.Dto;

import lombok.Data;
import java.util.List;

@Data
public class DeliveryAssignmentRequest {
    private int numDrivers;
    private List<OrderInput> orders;
}