package com.loginext.deliverymanagement.Model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "assignment_results")
@Data
@NoArgsConstructor
public class AssignmentResult {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerId;
    private int orderTime;
    private int travelTime;
    private String assignedDriverId;
    private String status;

    public AssignmentResult(String customerId, int orderTime, int travelTime, String assignedDriverId, String status) {
        this.customerId = customerId;
        this.orderTime = orderTime;
        this.travelTime = travelTime;
        this.assignedDriverId = assignedDriverId;
        this.status = status;
    }
}
